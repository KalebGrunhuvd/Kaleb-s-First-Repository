function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(0,0, 255);
   fill("red")
  triangle(130,100, 178, 80, 178,140)
  ellipse(100, 100, 75, 50)
  fill("Yellow")
  ellipse(75, 100, 30, 25)
  fill("White")
  ellipse(75, 100, 10, 10)
   fill(210, 180, 140)
  rect(0, 200, 400, 200)
 

 
}
